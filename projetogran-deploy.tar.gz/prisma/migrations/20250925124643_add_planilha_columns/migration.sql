-- AlterTable
ALTER TABLE "PeriodoSheet" ADD COLUMN "centroCusto" TEXT;
ALTER TABLE "PeriodoSheet" ADD COLUMN "codigo" TEXT;
ALTER TABLE "PeriodoSheet" ADD COLUMN "codigoCentroCusto" TEXT;
ALTER TABLE "PeriodoSheet" ADD COLUMN "embarcacaoAtual" TEXT;
ALTER TABLE "PeriodoSheet" ADD COLUMN "empresa" TEXT;
ALTER TABLE "PeriodoSheet" ADD COLUMN "formula" TEXT;
ALTER TABLE "PeriodoSheet" ADD COLUMN "lider" TEXT;
ALTER TABLE "PeriodoSheet" ADD COLUMN "observacoesAnterior" TEXT;
ALTER TABLE "PeriodoSheet" ADD COLUMN "plataforma" TEXT;
ALTER TABLE "PeriodoSheet" ADD COLUMN "status" TEXT;
ALTER TABLE "PeriodoSheet" ADD COLUMN "statusFolha" TEXT;
