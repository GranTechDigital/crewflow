-- AlterTable
ALTER TABLE "PeriodoSheet" ADD COLUMN "centroCusto" TEXT;
