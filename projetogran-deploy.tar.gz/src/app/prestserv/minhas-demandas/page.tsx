// app/page.tsx
export default function Home() {
  return <h1 className="text-2xl font-bold">Bem-vindo a Pagina Minhas Demandas da Logistica!</h1>;
}
